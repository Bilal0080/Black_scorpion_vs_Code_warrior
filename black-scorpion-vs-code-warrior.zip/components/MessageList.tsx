
import React, { useEffect, useRef } from 'react';
import { Message, Role, RagSource } from '../types';

interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
  onSuggestionClick: (text: string) => void;
}

const MessageList: React.FC<MessageListProps> = ({ messages, isLoading, onSuggestionClick }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isLoading]);

  const renderContent = (text: string, isModel: boolean, sources?: RagSource[]) => {
    const segments = text.split(/(### .*?\n|```[\s\S]*?```)/g);
    let staggerIndex = 0;
    
    return (
      <>
        {segments.map((segment, i) => {
          if (segment.trim() === '') return null;
          staggerIndex++;
          const staggerClass = isModel ? `animate-message stagger-${Math.min(staggerIndex, 5)}` : '';

          if (segment.startsWith('### 🔍 Pulse Detection')) {
            return <h3 key={i} className={`mt-6 mb-3 flex items-center gap-2 text-emerald-400 font-extrabold uppercase tracking-[0.2em] text-[10px] bg-emerald-500/5 py-2 px-4 rounded-full border border-emerald-500/20 ${staggerClass}`}>PULSE SIGNATURE</h3>;
          }
          if (segment.startsWith('### 📚 Vault Retrieval')) {
            return <h3 key={i} className={`mt-8 mb-3 flex items-center gap-2 text-indigo-400 font-extrabold uppercase tracking-[0.2em] text-[10px] bg-indigo-500/5 py-2 px-4 rounded-full border border-indigo-500/20 ${staggerClass}`}>VAULT SYNC</h3>;
          }
          if (segment.startsWith('### 🛠️ Code Pulse Correction')) {
            return <h3 key={i} className={`mt-8 mb-3 flex items-center gap-2 text-amber-400 font-extrabold uppercase tracking-[0.2em] text-[10px] bg-amber-500/5 py-2 px-4 rounded-full border border-amber-500/20 ${staggerClass}`}>REMEDIATION SCRIPT</h3>;
          }
          if (segment.startsWith('### 🚀 Scalability Forecast')) {
            return <h3 key={i} className={`mt-8 mb-3 flex items-center gap-2 text-cyan-400 font-extrabold uppercase tracking-[0.2em] text-[10px] bg-cyan-500/5 py-2 px-4 rounded-full border border-cyan-500/20 ${staggerClass}`}>SYSTEM FORECAST</h3>;
          }
          
          if (segment.startsWith('```')) {
            const code = segment.replace(/```(\w+)?\n?/, '').replace(/```$/, '');
            return (
              <div key={i} className={`my-6 relative group ${staggerClass}`}>
                <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 rounded-2xl blur-md opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                <pre className="relative bg-[#070b14]/80 backdrop-blur-md p-6 rounded-2xl overflow-x-auto text-[13px] font-mono text-emerald-400/90 border border-white/5 shadow-2xl">
                  <div className="absolute top-3 right-4 flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-slate-800 border border-white/5"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-slate-800 border border-white/5"></div>
                  </div>
                  <code>{code}</code>
                </pre>
                <button 
                  onClick={() => navigator.clipboard.writeText(code)} 
                  className="absolute bottom-4 right-4 p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 opacity-0 group-hover:opacity-100 transition-all border border-emerald-500/20 hover:bg-emerald-500/20"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                </button>
              </div>
            );
          }
          return <p key={i} className={`whitespace-pre-wrap leading-relaxed mb-4 text-slate-300 text-[15px] ${staggerClass}`}>{segment.replace(/### .*?\n/, '')}</p>;
        })}

        {sources && sources.length > 0 && (
          <div className="mt-8 pt-8 border-t border-white/5 space-y-4 animate-message stagger-5">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-2 px-1">Retrieved Context Sources:</span>
            <div className="flex flex-wrap gap-4">
              {sources.map((source, idx) => (
                <div key={idx} className="glass-card px-5 py-4 rounded-2xl border-indigo-500/10 flex items-start gap-4 max-w-xs group cursor-help hover:border-indigo-500/30 transition-all">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 flex-shrink-0 group-hover:bg-indigo-500/20 transition-all group-hover:scale-110">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-[12px] font-black text-indigo-300 group-hover:text-indigo-200 transition-colors">{source.title}</h4>
                    <p className="text-[11px] text-slate-500 line-clamp-2 italic leading-relaxed mt-1">{source.snippet}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </>
    );
  };

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 md:p-10 space-y-16 max-w-5xl mx-auto w-full scroll-smooth no-scrollbar">
      {messages.length === 0 && (
        <div className="flex flex-col items-center justify-center h-full text-center space-y-12 py-20 animate-message">
          <div className="relative group animate-float">
            <div className="absolute inset-0 bg-emerald-500/20 blur-[100px] rounded-full group-hover:bg-emerald-500/30 transition-all duration-1000"></div>
            <div className="relative w-40 h-40 bg-slate-900/40 backdrop-blur-3xl rounded-[3.5rem] border border-white/10 flex items-center justify-center shadow-2xl transition-all duration-700 group-hover:scale-105 group-hover:border-emerald-500/30">
               <div className="absolute inset-0 rounded-[3.5rem] border-2 border-emerald-500/10 pulse-ring-slow"></div>
               <svg xmlns="http://www.w3.org/2000/svg" className="w-20 h-20 text-emerald-400 opacity-80 glow-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
            </div>
          </div>
          <div className="space-y-6">
            <h2 className="text-5xl font-black tracking-tighter text-white italic uppercase bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-500">
              Black Scorpion <span className="text-emerald-500">Vault</span>
            </h2>
            <div className="h-1 w-20 bg-gradient-to-r from-emerald-500 to-transparent mx-auto rounded-full opacity-50"></div>
            <p className="text-slate-500 max-w-md mx-auto leading-relaxed text-[11px] font-black tracking-[0.4em] uppercase opacity-80">
              WARRIOR ENGINE READY. TERMINAL SYNCHRONIZATION ESTABLISHED. <br/>AWAITING KNOWLEDGE QUERY.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-3xl px-4 mt-4">
            <button onClick={() => onSuggestionClick("How do I build a Todo app and deploy to Google Cloud?")} className="group p-10 glass-card rounded-[3rem] text-left hover:border-emerald-500/40 hover:bg-emerald-500/5 transition-all duration-700 hover:-translate-y-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.8)]"></div>
                <span className="font-black text-[10px] uppercase tracking-[0.3em] text-emerald-500">RAG Retrieval</span>
              </div>
              <span className="block font-black text-slate-100 group-hover:text-emerald-400 transition-colors text-xl italic tracking-tight">GCP Todo Blueprint</span>
              <p className="text-slate-500 text-[12px] mt-4 leading-relaxed font-medium group-hover:text-slate-400 transition-colors">Comprehensive orchestration for containerizing and deploying to Cloud Run architecture.</p>
            </button>
            <button onClick={() => onSuggestionClick("How do I configure Qwen API keys?")} className="group p-10 glass-card rounded-[3rem] text-left hover:border-amber-500/40 hover:bg-amber-500/5 transition-all duration-700 hover:-translate-y-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.8)]"></div>
                <span className="block font-black text-[10px] uppercase tracking-[0.3em] text-amber-500">Environment Sync</span>
              </div>
              <span className="block font-black text-slate-100 group-hover:text-amber-400 transition-colors text-xl italic tracking-tight">Qwen / DashScope Config</span>
              <p className="text-slate-500 text-[12px] mt-4 leading-relaxed font-medium group-hover:text-slate-400 transition-colors">Establish secure uplink with DASHSCOPE_API_KEY for distributed Qwen model access.</p>
            </button>
          </div>
        </div>
      )}

      {messages.map((msg) => (
        <div key={msg.id} className={`flex ${msg.role === Role.USER ? 'justify-end' : 'justify-start'} animate-message`}>
          <div className={`relative max-w-[92%] md:max-w-[85%] rounded-[2.5rem] p-8 md:p-10 shadow-2xl transition-all duration-700 ${
            msg.role === Role.USER 
              ? 'bg-gradient-to-br from-emerald-600/90 via-emerald-700/90 to-cyan-800/90 backdrop-blur-xl text-white rounded-tr-none border border-white/20 hover:shadow-emerald-500/10' 
              : 'glass-card rounded-tl-none hover:border-white/10'
          }`}>
            {msg.role === Role.MODEL && (
              <div className="absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b from-indigo-500 via-emerald-500 to-transparent opacity-30"></div>
            )}
            <div className="prose prose-invert prose-sm max-w-none prose-p:leading-relaxed prose-pre:bg-transparent">
              {renderContent(msg.text, msg.role === Role.MODEL, msg.sources)}
            </div>
            <div className={`mt-8 flex items-center gap-3 text-[10px] font-black uppercase tracking-widest opacity-30 ${msg.role === Role.USER ? 'text-white' : 'text-slate-500'}`}>
              <div className={`w-1.5 h-1.5 rounded-full ${msg.role === Role.USER ? 'bg-white' : 'bg-emerald-500'}`}></div>
              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} — {msg.role === Role.USER ? 'WARRIOR_TERMINAL_01' : 'SCORPION_CORE_RETRIEVAL'}
            </div>
          </div>
        </div>
      ))}
      
      {isLoading && (
        <div className="flex justify-start animate-message">
          <div className="glass-card px-10 py-8 rounded-[3rem] rounded-tl-none flex items-center gap-8 shadow-2xl border-indigo-500/10 relative overflow-hidden group data-stream">
            <div className="flex space-x-3 relative z-10">
              <div className="w-3 h-3 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
              <div className="w-3 h-3 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '200ms' }}></div>
              <div className="w-3 h-3 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '400ms' }}></div>
            </div>
            <div className="flex flex-col relative z-10">
              <span className="text-[11px] text-emerald-500 font-black uppercase tracking-[0.4em] mb-1">Vault_Querying</span>
              <span className="text-[12px] text-slate-400 font-bold tracking-tight animate-pulse">Retrieving strategic payload...</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MessageList;
