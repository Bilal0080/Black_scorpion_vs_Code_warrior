
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="h-24 border-b border-white/5 bg-slate-950/60 backdrop-blur-3xl flex items-center justify-between px-10 md:px-12 sticky top-0 z-[60] shadow-2xl">
      <div className="flex items-center gap-6 group cursor-default">
        <div className="relative">
          <div className="absolute inset-0 bg-emerald-500 rounded-2xl blur-2xl opacity-10 group-hover:opacity-30 transition-opacity duration-1000"></div>
          <div className="absolute -inset-2 border border-emerald-500/5 rounded-2xl pulse-ring-slow"></div>
          <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 via-emerald-600 to-cyan-700 rounded-2xl flex items-center justify-center relative z-10 shadow-2xl overflow-hidden border border-white/10 group-hover:scale-105 transition-transform duration-700">
            <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="scanline"></div>
            <svg xmlns="http://www.w3.org/2000/svg" className="w-7 h-7 text-white group-hover:rotate-12 transition-all duration-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
        </div>
        <div>
          <h1 className="text-2xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-100 to-slate-400 transition-all duration-700 group-hover:tracking-tight italic uppercase">
            BLACK SCORPION <span className="text-emerald-400 non-italic">vs CODE WARRIOR</span>
          </h1>
          <div className="flex items-center gap-3 mt-1 opacity-80">
            <div className="flex space-x-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)] animate-pulse"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500/40"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500/20"></span>
            </div>
            <p className="text-[10px] text-slate-500 uppercase tracking-[0.5em] font-black">Warrior_Kernel_v5.2.0_Stable</p>
          </div>
        </div>
      </div>
      
      <div className="hidden lg:flex items-center gap-12">
        <div className="flex flex-col items-end">
          <span className="text-[10px] font-black text-slate-600 uppercase tracking-[0.4em] mb-1">Bridge_Node_Active</span>
          <div className="flex items-center gap-3 px-3 py-1.5 rounded-full bg-emerald-500/5 border border-emerald-500/10">
            <span className="text-[11px] font-black text-emerald-400 uppercase italic tracking-widest flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"></span>
              Synchronized
            </span>
          </div>
        </div>
        <div className="h-10 w-[1px] bg-white/10"></div>
        <div className="flex items-center gap-4">
           <button className="w-10 h-10 rounded-xl border border-white/5 flex items-center justify-center bg-white/5 hover:bg-emerald-500/10 hover:border-emerald-500/20 transition-all cursor-pointer group" title="Network Topology">
             <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-slate-500 group-hover:text-emerald-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
             </svg>
           </button>
           <button className="w-10 h-10 rounded-xl border border-white/5 flex items-center justify-center bg-white/5 hover:bg-emerald-500/10 hover:border-emerald-500/20 transition-all cursor-pointer group" title="System Configuration">
             <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-slate-500 group-hover:text-emerald-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
             </svg>
           </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
