
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { Role, Message, RagSource } from "../types";

const MODEL_NAME = 'gemini-3-flash-preview';

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async solveError(query: string, history: Message[], image?: { data: string; mimeType: string }): Promise<Partial<Message>> {
    try {
      const contents = history.map(m => {
        const parts: any[] = [{ text: m.text }];
        if (m.image) {
          parts.push({
            inlineData: {
              data: m.image.data,
              mimeType: m.image.mimeType
            }
          });
        }
        return {
          role: m.role === Role.USER ? 'user' : 'model',
          parts
        };
      });

      const currentParts: any[] = [{ text: query }];
      if (image) {
        currentParts.push({
          inlineData: {
            data: image.data,
            mimeType: image.mimeType
          }
        });
      }

      contents.push({
        role: 'user',
        parts: currentParts
      });

      const response: GenerateContentResponse = await this.ai.models.generateContent({
        model: MODEL_NAME,
        contents,
        config: {
          systemInstruction: `You are Black Scorpion, a RAG-enabled DevOps architect and "Code Warrior" companion.

          MISSION: QWEN & OLLAMA CONFIGURATION (CLAUDE CODE STYLE):
          - When asked to configure keys or setup Qwen/Ollama, initiate the "Warrior Node Sync" protocol:
            1. **Qwen (DashScope)**:
               - Request the user visit: https://dashscope.console.aliyun.com/
               - Provide explicit CLI commands for setting DASHSCOPE_API_KEY.
               - Show how to verify: 'curl -v https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation'
            2. **Ollama (Local Node)**:
               - Verify binary installation: 'ollama --version'
               - Command to start server: 'ollama serve'
               - Command to pull Qwen model: 'ollama pull qwen2.5:7b-instruct'
               - Test local endpoint: 'curl http://localhost:11434/api/generate'
          - Frame these steps as a robust "Setup Wizard" similar to the 'claude config' experience.

          MISSION: AI STRATEGY & ROADMAP:
          - Guide users on building AI agents using Google AI Studio.
          - Phase 1: Rapid Prototyping (System Instructions + Gemini 3 Flash).
          - Phase 2: Knowledge Augmentation (RAG with Neural Vault).
          - Phase 3: Tool Integration (Google Search, Maps, custom function calling).
          - Phase 4: Multi-cloud Deployment (GCP Cloud Run / Azure Web Apps).

          MISSION: PLATFORM PULSE COMPARISON:
          - If asked which platform is best for IT issues:
            1. **Google Gemini (AI Studio)**: The "Context King". Best for IT issues because of the 1M+ token context window.
            2. **Claude**: The "Reasoning Specialist". Best for logic-heavy refactoring.
            3. **Azure OpenAI**: The "Enterprise Guard".
          - **Verdict**: Recommend Gemini for log-heavy terminal debugging.

          RESPONSE ARCHITECTURE:
          - ### 🔍 Pulse Detection: Query ID.
          - ### 🗺️ Strategic Roadmap: For build queries.
          - ### 🛠️ Code Pulse Correction: Actionable CLI/Code blocks.
          - ### ⚙️ Warrior Node Config: Dedicated section for LLM setup.`,
          tools: [{ googleSearch: {} }],
        },
      });

      const text = response.text || "Pulse flatline. Reconnecting...";
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      
      const simulatedSources: RagSource[] = [];
      if (query.toLowerCase().includes('roadmap') || query.toLowerCase().includes('build')) {
        simulatedSources.push({ title: "Google AI Studio Quickstart", snippet: "Using API keys and system instructions for rapid agent development...", relevance: 0.99 });
      }
      if (query.toLowerCase().includes('platform') || query.toLowerCase().includes('best')) {
        simulatedSources.push({ title: "LLM Comparison Matrix 2025", snippet: "Gemini 3 Pro vs Claude 3.5 Sonnet for Debugging Tasks...", relevance: 0.97 });
      }
      if (query.toLowerCase().includes('qwen') || query.toLowerCase().includes('config')) {
        simulatedSources.push({ title: "DashScope API Documentation", snippet: "Guide for managing sk- API keys for Qwen cloud inference...", relevance: 0.98 });
      }

      return {
        text,
        groundingUrls: groundingChunks.filter(chunk => chunk.web),
        sources: simulatedSources.length > 0 ? simulatedSources : undefined,
        role: Role.MODEL
      };
    } catch (error) {
      console.error("Gemini API Error:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
